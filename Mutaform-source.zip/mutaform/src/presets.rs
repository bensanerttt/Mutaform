//! Factory presets. Applied from the GUI through the host's parameter setter so they are
//! recorded as normal parameter changes (undo/automation friendly).

use crate::params::{DetectRange, FxKind, MidiMode, MutaformParams, NUM_FX_SLOTS};
use nih_plug::prelude::*;

#[derive(Clone, Copy)]
pub struct FxPreset {
    pub kind: FxKind,
    pub a: f32,
    pub b: f32,
    pub mix: f32,
}

const FX_OFF: FxPreset = FxPreset { kind: FxKind::Off, a: 0.5, b: 0.5, mix: 0.5 };

#[derive(Clone, Copy)]
pub struct Preset {
    pub name: &'static str,
    pub pitch: f32,
    pub formant: f32,
    pub harmonics: f32,
    pub ratio: f32,
    pub fm: f32,
    pub snap: bool,
    pub alternator: f32,
    pub octave: f32,
    pub glide: f32,
    pub smear: f32,
    pub stereo: f32,
    pub detune: f32,
    pub dry_wet: f32,
    pub midi_mode: MidiMode,
    pub detect: DetectRange,
    pub fx: [FxPreset; NUM_FX_SLOTS],
}

const INIT: Preset = Preset {
    name: "Init",
    pitch: 0.0,
    formant: 0.0,
    harmonics: 0.0,
    ratio: 1.0,
    fm: 0.0,
    snap: false,
    alternator: 0.0,
    octave: 0.0,
    glide: 0.0,
    smear: 0.0,
    stereo: 0.0,
    detune: 0.0,
    dry_wet: 1.0,
    midi_mode: MidiMode::Off,
    detect: DetectRange::Mid,
    fx: [FX_OFF; NUM_FX_SLOTS],
};

const fn fx(kind: FxKind, a: f32, b: f32, mix: f32) -> FxPreset {
    FxPreset { kind, a, b, mix }
}

pub const PRESETS: &[Preset] = &[
    INIT,
    Preset { name: "Deep Ogre", pitch: -12.0, formant: -6.0, detect: DetectRange::Mid, ..INIT },
    Preset { name: "Helium", pitch: 12.0, formant: 7.0, ..INIT },
    Preset { name: "Gender Flip", pitch: 5.0, formant: 3.5, ..INIT },
    Preset { name: "Big Guy", pitch: -5.0, formant: -3.0, ..INIT },
    Preset {
        name: "Robot Choir",
        harmonics: 0.5,
        snap: true,
        detune: 0.6,
        stereo: 0.5,
        fx: [fx(FxKind::Chorus, 0.3, 0.5, 0.4), fx(FxKind::Reverb, 0.6, 0.4, 0.3), FX_OFF, FX_OFF],
        ..INIT
    },
    Preset { name: "Octave Stack", octave: -0.6, detune: 0.3, stereo: 0.3, ..INIT },
    Preset {
        name: "Sub Alternator",
        alternator: 0.8,
        formant: -2.0,
        fx: [fx(FxKind::LowPass, 0.75, 0.3, 1.0), FX_OFF, FX_OFF, FX_OFF],
        ..INIT
    },
    Preset { name: "Hollow Down", alternator: -0.8, ..INIT },
    Preset {
        name: "FM Growl",
        pitch: -12.0,
        fm: 0.6,
        ratio: 2.0,
        snap: true,
        fx: [fx(FxKind::Drive, 0.4, 0.6, 0.6), FX_OFF, FX_OFF, FX_OFF],
        ..INIT
    },
    Preset {
        name: "Metal Throat",
        harmonics: 0.37,
        fm: 0.25,
        ratio: 1.5,
        fx: [fx(FxKind::HighPass, 0.25, 0.2, 1.0), fx(FxKind::Reverb, 0.5, 0.5, 0.25), FX_OFF, FX_OFF],
        ..INIT
    },
    Preset {
        name: "Smear Cloud",
        smear: 0.8,
        stereo: 0.9,
        detune: 0.5,
        fx: [fx(FxKind::Delay, 0.55, 0.45, 0.35), fx(FxKind::Reverb, 0.85, 0.3, 0.5), FX_OFF, FX_OFF],
        ..INIT
    },
    Preset { name: "MIDI Mono Lead", midi_mode: MidiMode::Mono, glide: 80.0, stereo: 0.2, ..INIT },
    Preset {
        name: "MIDI Poly Harmonizer",
        midi_mode: MidiMode::Poly,
        detune: 0.25,
        stereo: 0.4,
        dry_wet: 0.6,
        fx: [fx(FxKind::Reverb, 0.6, 0.5, 0.3), FX_OFF, FX_OFF, FX_OFF],
        ..INIT
    },
    Preset {
        name: "Lo-Fi Radio",
        formant: 2.0,
        fx: [
            fx(FxKind::HighPass, 0.4, 0.3, 1.0),
            fx(FxKind::LowPass, 0.6, 0.3, 1.0),
            fx(FxKind::Crush, 0.55, 0.15, 0.7),
            FX_OFF,
        ],
        ..INIT
    },
    Preset {
        name: "Wobble Monster",
        pitch: -7.0,
        formant: -4.0,
        harmonics: -0.25,
        snap: true,
        fx: [fx(FxKind::Tremolo, 0.35, 0.7, 1.0), fx(FxKind::Drive, 0.5, 0.5, 0.5), FX_OFF, FX_OFF],
        ..INIT
    },
];

pub fn apply(p: &Preset, params: &MutaformParams, setter: &ParamSetter) {
    fn set<P: Param>(setter: &ParamSetter, param: &P, v: P::Plain) {
        setter.begin_set_parameter(param);
        setter.set_parameter(param, v);
        setter.end_set_parameter(param);
    }
    set(setter, &params.pitch, p.pitch);
    set(setter, &params.formant, p.formant);
    set(setter, &params.harmonics, p.harmonics);
    set(setter, &params.ratio, p.ratio);
    set(setter, &params.fm, p.fm);
    set(setter, &params.snap, p.snap);
    set(setter, &params.alternator, p.alternator);
    set(setter, &params.octave, p.octave);
    set(setter, &params.glide, p.glide);
    set(setter, &params.smear, p.smear);
    set(setter, &params.stereo, p.stereo);
    set(setter, &params.detune, p.detune);
    set(setter, &params.dry_wet, p.dry_wet);
    set(setter, &params.midi_mode, p.midi_mode);
    set(setter, &params.detect, p.detect);
    for (slot, f) in params.fx.iter().zip(p.fx.iter()) {
        set(setter, &slot.kind, f.kind);
        set(setter, &slot.a, f.a);
        set(setter, &slot.b, f.b);
        set(setter, &slot.mix, f.mix);
    }
}
